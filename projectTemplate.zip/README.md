# CRUD App
simple CRUD app using spring MVC , Hibernate , mysql , Maven and Bootstrap4

![alt text](https://stackjava.com/wp-content/uploads/2017/12/spring-mvc-logo.png)
![alt text](https://design.jboss.org/hibernate/logo/final/hibernate_logo_whitebkg_stacked_256px.png)
![alt text](https://cdn.iconscout.com/icon/free/png-256/mysql-6-226028.png)
![alt text](https://roufid.com/wp-content/uploads/2016/05/eyecatch-maven.png)
![alt text](https://cdn.iconscout.com/icon/free/png-256/bootstrap-6-1175203.png)

you can clone the repository for the project code template or for the full source code
